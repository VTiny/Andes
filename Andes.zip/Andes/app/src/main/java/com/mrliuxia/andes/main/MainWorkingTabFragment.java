package com.mrliuxia.andes.main;

import com.mrliuxia.andes.R;
import com.mrliuxia.andes.base.BaseListFragment;

/**
 * Author: liuxiao
 * Created: 2019/1/15 11:46
 * Description:
 */
public class MainWorkingTabFragment extends BaseListFragment {

    @Override
    protected String getAssetDataPath() {
        return "data/list_working.json";
    }
}
