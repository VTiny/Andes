package com.mrliuxia.andes.list;

/**
 * Description:
 * Author: liuxiao
 * Date: 2019/3/20
 */
public interface ListProtocol {

    String STYLE_LARGE_DIVIDER = "simple_large_divider";

}
