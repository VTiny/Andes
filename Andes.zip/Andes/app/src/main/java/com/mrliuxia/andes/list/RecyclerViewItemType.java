package com.mrliuxia.andes.list;

/**
 * Description:
 * Author: liuxiao
 * Date: 2019/3/19
 */
public interface RecyclerViewItemType {

    int ITEM_TYPE_NORMAL = 0;
    int ITEM_TYPE_LARGE_DIVIDER = ITEM_TYPE_NORMAL + 1;

}
