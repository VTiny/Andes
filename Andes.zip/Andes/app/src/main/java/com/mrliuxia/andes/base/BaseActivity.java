package com.mrliuxia.andes.base;

import android.support.v7.app.AppCompatActivity;

/**
 * Author: liuxiao
 * Created: 2019/1/12 18:33
 * Description:
 */
public class BaseActivity extends AppCompatActivity {
}
