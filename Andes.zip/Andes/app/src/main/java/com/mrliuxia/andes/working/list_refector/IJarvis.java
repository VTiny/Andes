package com.mrliuxia.andes.working.list_refector;

/**
 * Description:
 * Author: liuxia
 * Data: 1/11/21
 *
 * @blame: liuxia
 */
public interface IJarvis {

    boolean dispatchCommand(JarvisCommand command, Object args);

}

