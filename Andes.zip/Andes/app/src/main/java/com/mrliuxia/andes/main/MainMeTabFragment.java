package com.mrliuxia.andes.main;

import com.mrliuxia.andes.R;
import com.mrliuxia.andes.base.BaseFragment;

/**
 * Author: liuxiao
 * Created: 2019/1/12 18:29
 * Description:
 */
public class MainMeTabFragment extends BaseFragment {

    @Override
    protected int getContentViewLayout() {
        return R.layout.main_me_layout;
    }
}
