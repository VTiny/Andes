package com.mrliuxia.andes.working.list_refector;

/**
 * Description:
 * Author: liuxia
 * Data: 1/11/21
 *
 * @blame: liuxia
 */
public enum WorkerType {

    LIST,

    LOAD_NET,

    LOAD_LOCAL,

    STATE_VIEW,

}
