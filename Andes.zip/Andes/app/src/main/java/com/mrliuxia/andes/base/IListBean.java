package com.mrliuxia.andes.base;

/**
 * Description:
 * Author: liuxiao
 * Date: 2019/2/18
 */
public interface IListBean {
}
